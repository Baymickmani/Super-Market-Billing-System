create table users(
userId int,
userName varchar(25),
password varchar(25),
userType int,
primary key(userId)
);

insert into users values(7001,'admin','admin',1);
insert into users values(7002,'biller1','biller',2);