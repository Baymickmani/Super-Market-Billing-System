package com.training.advice;

import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
@Aspect
public class LoggingAdvice {
	
	@Around("execution(* com.training.project.service.ProductServiceImpl.*(..))")
	public Object logAroundProductServiceMethods(ProceedingJoinPoint joinPoint) throws Throwable{
		Object obj=null;
		FileWriter fw=null;
		Calendar calendar=Calendar.getInstance();
		int month=calendar.get(Calendar.MONTH)+1;
		String fileNameStr=calendar.get(Calendar.YEAR)+"-"+month+"-"+calendar.get(Calendar.DATE);
		fileNameStr=fileNameStr+".log";
		
		String serverHome=System.getProperty("catalina.home");
		String serverFile=serverHome+"\\"+"prodLogs"+"\\"+fileNameStr;
		System.out.println(serverFile);
		fw=new FileWriter(serverFile,true);
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		String dateStr=sdf.format(date);
		StringBuffer buffer=new StringBuffer();
		buffer.append("[");
		buffer.append(dateStr);
		buffer.append("\t");
		
		
		String methodName=joinPoint.getSignature().getName();
		Object[] params=joinPoint.getArgs();
		String paramStr=Arrays.toString(params);
		buffer.append("\t");
		buffer.append(methodName);
		buffer.append(paramStr);
		obj=joinPoint.proceed();
		
		buffer.append("=");
		buffer.append("\t");
		buffer.append(obj);
		buffer.append(")\n");
		String logStr=buffer.toString();
		fw.write(logStr);
		fw.flush();
		fw.close();
		return obj;
	}
	
	@Around("execution(* com.training.project.service.CustomerServiceImpl.*(..))")
	public Object logAroundCustomerServiceMethods(ProceedingJoinPoint joinPoint) throws Throwable{
		Object obj=null;
		FileWriter fw=null;
		Calendar calendar=Calendar.getInstance();
		int month=calendar.get(Calendar.MONTH)+1;
		String fileNameStr=calendar.get(Calendar.YEAR)+"-"+month+"-"+calendar.get(Calendar.DATE);
		fileNameStr=fileNameStr+".log";
		
		String serverHome=System.getProperty("catalina.home");
		String serverFile=serverHome+"\\"+"customerLogs"+"\\"+fileNameStr;
		System.out.println(serverFile);
		fw=new FileWriter(serverFile,true);
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		String dateStr=sdf.format(date);
		StringBuffer buffer=new StringBuffer();
		buffer.append("[");
		buffer.append(dateStr);
		buffer.append("\t");
		
		
		String methodName=joinPoint.getSignature().getName();
		Object[] params=joinPoint.getArgs();
		String paramStr=Arrays.toString(params);
		buffer.append("\t");
		buffer.append(methodName);
		buffer.append(paramStr);
		obj=joinPoint.proceed();
		
		buffer.append("=");
		buffer.append("\t");
		buffer.append(obj);
		buffer.append(")\n");
		String logStr=buffer.toString();
		fw.write(logStr);
		fw.flush();
		fw.close();
		return obj;
	}
}
