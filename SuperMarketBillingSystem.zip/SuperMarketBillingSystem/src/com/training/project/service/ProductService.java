package com.training.project.service;

import java.util.List;

import com.training.project.bean.Product;

public interface ProductService {
	boolean addProduct(Product product) throws Exception;
	boolean deleteProduct(Product product) throws Exception;
	boolean updateProduct(Product product) throws Exception;
	Product findProduct(int id) throws Exception;
	List<Product> getAll() throws Exception; 
}
