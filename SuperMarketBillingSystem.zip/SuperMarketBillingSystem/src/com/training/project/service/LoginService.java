package com.training.project.service;

import com.training.project.bean.Login;

public interface LoginService {
	Login find(String userName) throws Exception; 
}
