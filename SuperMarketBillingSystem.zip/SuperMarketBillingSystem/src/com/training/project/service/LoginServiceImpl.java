package com.training.project.service;


import org.springframework.stereotype.Service;

import com.training.project.bean.Login;
import com.training.project.dao.LoginDAO;
@Service
public class LoginServiceImpl implements LoginService {
	LoginDAO dao;

	public LoginDAO getDao() {
		return dao;
	}

	public void setDao(LoginDAO dao) {
		this.dao = dao;
	}

	@Override
	public Login find(String userName) throws Exception {
		
		return dao.find(userName);
	}
	
	
}
