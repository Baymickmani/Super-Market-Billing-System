package com.training.project.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.training.project.bean.Product;
import com.training.project.dao.ProductDAO;
@Service
public class ProductServiceImpl implements ProductService{
	ProductDAO dao;

	public ProductDAO getDao() {
		return dao;
	}

	public void setDao(ProductDAO dao) {
		this.dao = dao;
	}
	@Override
	public boolean addProduct(Product product) throws Exception {
	
		return this.dao.addProduct(product);
	}
	
	@Override
	public List<Product> getAll() throws Exception {
		return this.dao.getAll();
	}

	@Override
	public boolean deleteProduct(Product product) throws Exception {
		return this.dao.deleteProduct(product);
	}

	@Override
	public boolean updateProduct(Product product) throws Exception {
	
		return this.dao.updateProduct(product);
	}

	@Override
	public Product findProduct(int id) throws Exception {
		System.out.println(id);
		return this.dao.findProduct(id);
	}

	
}
