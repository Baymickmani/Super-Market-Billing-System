package com.training.project.service;

import java.util.List;

import com.training.project.bean.Bill;

public interface BillService {
	boolean addBill(Bill bill)throws Exception;
	boolean deleteBill(Bill bill)throws Exception;
	boolean updateBill(Bill bill)throws Exception;
	Bill findBill(int id)throws Exception;
	List<Bill> getAllBills()throws Exception;

}
