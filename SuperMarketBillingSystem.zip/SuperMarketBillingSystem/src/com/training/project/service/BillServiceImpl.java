package com.training.project.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.training.project.bean.Bill;
import com.training.project.dao.BillDAO;

@Service
public class BillServiceImpl implements BillService {
	BillDAO dao;

	public BillDAO getDao() {
		return dao;
	}

	public void setDao(BillDAO dao) {
		this.dao = dao;
	}
	
	@Override
	
	public boolean addBill(Bill bill) throws Exception {
		boolean result=dao.addBill(bill);
		System.out.println(bill.getBillId());
		return result;
	}

	@Override
	public boolean deleteBill(Bill bill) throws Exception {
		
		return dao.deleteBill(bill);
	}

	@Override
	public boolean updateBill(Bill bill) throws Exception {
		
		return dao.updateBill(bill);
	}

	@Override
	public Bill findBill(int id) throws Exception {
		
		return dao.findBill(id);
	}

	@Override
	public List<Bill> getAllBills() throws Exception {
		
		return dao.getAllBills();
	}
}
