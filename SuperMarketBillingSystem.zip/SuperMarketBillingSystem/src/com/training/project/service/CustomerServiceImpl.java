package com.training.project.service;


import org.springframework.stereotype.Service;

import com.training.project.bean.Customer;
import com.training.project.dao.CustomerDAO;
@Service
public class CustomerServiceImpl implements CustomerService{
	CustomerDAO dao;

	public CustomerDAO getDao() {
		return dao;
	}

	public void setDao(CustomerDAO dao) {
		this.dao = dao;
	}

	@Override
	public boolean add(Customer customer) throws Exception {
		return this.dao.add(customer);
	}

	@Override
	public boolean update(Customer customer) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.update(customer);
	}

	@Override
	public boolean delete(Customer customer) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.delete(customer);
	}

	@Override
	public Customer findCustomer(String mobileNumber) throws Exception {
		
		return this.dao.findCustomer(mobileNumber);
	}
	
}
