package com.training.project.service;

import com.training.project.bean.Customer;

public interface CustomerService {
	boolean add(Customer customer)throws Exception;
	boolean update(Customer customer)throws Exception;
	boolean delete(Customer customer)throws Exception;
	Customer findCustomer(String mobileNumber)throws Exception;
}
