package com.training.project.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.project.bean.Bill;
@Repository
public class BillDAOImpl implements BillDAO{
	HibernateTemplate template;
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		this.template=new HibernateTemplate(this.sessionFactory);
		System.out.println("Hibernate Template is Ready");
	}

	@Override
	@Transactional
	public boolean addBill(Bill bill) throws Exception {
	
		boolean result=false;
		try
		{
		this.template.save(bill);
		result=true;
		}
		catch(Exception e)
		{
			result=false;
		}
		return result;
	}

	@Override
	@Transactional
	public boolean deleteBill(Bill bill) throws Exception {
		
		boolean result=false;
		try
		{
		this.template.delete(bill);
		result=true;
		}
		catch(Exception e)
		{
			result=false;
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateBill(Bill bill) throws Exception {
		boolean result=false;
		try
		{
		this.template.update(bill);
		result=true;
		}
		catch(Exception e)
		{
			result=false;
		}
		return result;
	}

	@Override
	@Transactional
	public Bill findBill(int id) throws Exception {

		Bill bill=null;
		bill=this.template.load(Bill.class,id);
		System.out.println(bill);
		return bill;
	}

	@Override
	public List<Bill> getAllBills() throws Exception {
		
		List<Bill> bills=null;
		bills=this.template.loadAll(Bill.class);
		return bills;
	}
}
