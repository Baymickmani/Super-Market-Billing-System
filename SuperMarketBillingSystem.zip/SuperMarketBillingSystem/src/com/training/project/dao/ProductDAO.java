package com.training.project.dao;

import java.util.List;

import com.training.project.bean.Product;

public interface ProductDAO {
	boolean addProduct(Product product) throws Exception;
	boolean deleteProduct(Product product) throws Exception;
	boolean updateProduct(Product product) throws Exception;
	Product findProduct(int id) throws Exception;
	List<Product> getAll() throws Exception;
}
