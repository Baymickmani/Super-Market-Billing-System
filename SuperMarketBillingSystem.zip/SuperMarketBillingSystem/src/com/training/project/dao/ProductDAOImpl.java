package com.training.project.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.project.bean.Product;
@Repository
public class ProductDAOImpl implements ProductDAO {
	HibernateTemplate template;
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		this.template = new HibernateTemplate(this.sessionFactory);	
		System.out.println("Hibernate Template is Ready");
	}
	@Override
	@Transactional
	public boolean addProduct(Product product) throws Exception {
		boolean result = false;

		try {
			this.template.save(product);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}
	
	@Override
	public List<Product> getAll() throws Exception {
		List<Product> products = null;
		products = this.template.loadAll(Product.class);
		return products;
	}
	@Override
	@Transactional
	public boolean deleteProduct(Product product) throws Exception {
		boolean result=false;
		try{
			this.template.delete(product);
			result=true;
		}
		catch(Exception e){
			e.printStackTrace();
			result=false;
		}
		return result;
	}
	@Override
	@Transactional
	public boolean updateProduct(Product product) throws Exception {
		boolean result=false;
		try{
			this.template.update(product);
			result=true;
		}
		catch(Exception e){
			e.printStackTrace();
			result=false;
		}
		return result;
	}
	@Override
	@Transactional
	public Product findProduct(int id) throws Exception {
		Product product=null;
		System.out.println(id);
		product=this.template.load(Product.class, id);
		System.out.println(product);
		return product;
	}

	
}
