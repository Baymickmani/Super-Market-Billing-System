package com.training.project.dao;

import com.training.project.bean.Customer;

public interface CustomerDAO {
	boolean add(Customer customer)throws Exception;
	boolean update(Customer customer)throws Exception;
	boolean delete(Customer customer)throws Exception;
	Customer findCustomer(String mobileNumber)throws Exception;
}
