package com.training.project.dao;



import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.project.bean.Login;
@Repository
public class LoginDAOImpl implements LoginDAO{
	HibernateTemplate template;
	private String username;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.template=new HibernateTemplate(sessionFactory);
		System.out.println("Hibernate Template is Ready");
	}

	@Override
	@Transactional
	public Login find(String userName) throws Exception {
		this.username=userName;
		Login login=null;
	    login=this.template.execute(new LoginACtion());
		System.out.println(login);
		return login;
	}
	
	
	
	private class LoginACtion  implements HibernateCallback<Login>{

		@Override
		public Login doInHibernate(Session arg0) throws HibernateException {
		String query="from Login as l where l.userName=:un";
		Query<Login> query2=arg0.createQuery(query);
		query2.setParameter("un", username);
		Login login=query2.getSingleResult();
			
		return login;
		}
	}
}
