package com.training.project.dao;

import com.training.project.bean.Login;

public interface LoginDAO {
	Login find(String userName) throws Exception;
}
