package com.training.project.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.project.bean.Customer;
@Repository
public class CustomerDAOImpl implements CustomerDAO {
	HibernateTemplate template;
	SessionFactory sessionFactory;
	private String customerPhone;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		this.template = new HibernateTemplate(this.sessionFactory);
		System.out.println("Hibernate Template is Ready");
	}
	@Transactional
	public boolean add(Customer customer) throws Exception {

		boolean result = false;
		try {
			this.template.save(customer);
			
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}
	@Transactional
	public boolean update(Customer customer) throws Exception {

		boolean result = false;
		try {
			this.template.update(customer);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}

		return result;
	}
	@Transactional
	public boolean delete(Customer customer) throws Exception {

		boolean result = false;
		try {
			this.template.delete(customer);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}

		return result;
	}
	@Override
	@Transactional
	public Customer findCustomer(String mobileNumber) throws Exception {

		Customer customer;
		this.customerPhone=mobileNumber;
		customer = this.template.execute(new CustomerRetrival());
		System.out.println(customer);
		return customer;

	}

	private class CustomerRetrival implements HibernateCallback<Customer> {
         @Override
		public Customer doInHibernate(Session arg0) throws HibernateException {
			String query = "from Customer as c where c.customerMobile=:cm";
			Query<Customer> query2 = arg0.createQuery(query);
			query2.setParameter("cm", customerPhone);
			Customer customer = query2.getSingleResult();
			return customer;
		}

	}

}
