package com.training.project.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import org.hibernate.annotations.Proxy;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name="adminProducts")
@Proxy(lazy=false)
public class Product {
	@Id
	@SequenceGenerator(name="adminProducts_seq1",sequenceName="adminProducts_seq",initialValue=1001,allocationSize=1)
	@GeneratedValue(generator="adminProducts_seq1",strategy=GenerationType.SEQUENCE)
	private int productId;
	@NotEmpty(message="ProductName cannot be blank")
	private String productName;
	@Range(min=1,max=50000,message="Out of range(1-50000)")
	private double productMRP;
	@Range(min=0,max=1,message="Out of range(0-1)")
	private double productDiscountPercentage;
	@NotEmpty(message="category cannot be blank")
	private String category;
	
	public Product() {
		super();
	}

	
	public Product(String productName, double productMRP, double productDiscountPercentage, String category) {
		super();
		this.productName = productName;
		this.productMRP = productMRP;
		this.productDiscountPercentage = productDiscountPercentage;
		this.category = category;
	}


	public Product(int productId, String productName, double productMRP, double productDiscountPercentage,
			String category) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productMRP = productMRP;
		this.productDiscountPercentage = productDiscountPercentage;
		this.category = category;
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public double getProductMRP() {
		return productMRP;
	}


	public void setProductMRP(double productMRP) {
		this.productMRP = productMRP;
	}


	public double getProductDiscountPercentage() {
		return productDiscountPercentage;
	}


	public void setProductDiscountPercentage(double productDiscountPercentage) {
		this.productDiscountPercentage = productDiscountPercentage;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}

	public double getProductValue(Product product){
		return product.getProductMRP()-product.getProductMRP()*product.getProductDiscountPercentage();
	}

	

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", productMRP=" + productMRP
				+ ", productDiscountPercentage=" + productDiscountPercentage
				+ ", category=" + category + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + productId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (productId != other.productId)
			return false;
		return true;
	}
	
	
	
	
	
}
