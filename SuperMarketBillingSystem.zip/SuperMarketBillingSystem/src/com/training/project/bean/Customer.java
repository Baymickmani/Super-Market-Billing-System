package com.training.project.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="CustomerDetails")
public class Customer {
	@Id
	@SequenceGenerator(name="customer_seq1",sequenceName="customer_seq",initialValue=101,allocationSize=1)
	@GeneratedValue(generator="customer_seq1",strategy=GenerationType.SEQUENCE)
	private int customerId;
	@NotEmpty(message="Name cannot be blank")
	private String customerName;
	private String customerMobile;
	@NotEmpty(message="Email cannot be blank")
	private String customerEmail;
	@Transient
	static int index=0;
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL)
	private List<Bill> bills;

	public Customer() {
		super();
		this.bills=new ArrayList<Bill>();
	}
	
	public Customer(String customerName, String customerMobile,
			String customerEmail, List<Bill> bills) {
		super();
		this.customerName = customerName;
		this.customerMobile = customerMobile;
		this.customerEmail = customerEmail;
		this.bills = new ArrayList<Bill>();
	}

	public Customer(int customerId, String customerName, String customerMobile,
			String customerEmail, List<Bill> bills) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerMobile = customerMobile;
		this.customerEmail = customerEmail;
		this.bills = new ArrayList<Bill>();
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerMobile() {
		return customerMobile;
	}

	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public List<Bill> getBills() {
		return bills;
	}

	public void setBills(List<Bill> bills) {
		this.bills = bills;
	}
	
	public void addBill(Bill bill){
		bills.add(bill);
		index++;
	}
	
	public int getIndex() {
		return index;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName="
				+ customerName + ", customerMobile=" + customerMobile
				+ ", customerEmail=" + customerEmail + ", bills=" + bills + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customerId;
		result = prime * result
				+ ((customerMobile == null) ? 0 : customerMobile.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerId != other.customerId)
			return false;
		if (customerMobile == null) {
			if (other.customerMobile != null)
				return false;
		} else if (!customerMobile.equals(other.customerMobile))
			return false;
		return true;
	}

	
	
	
	
	
	
}
