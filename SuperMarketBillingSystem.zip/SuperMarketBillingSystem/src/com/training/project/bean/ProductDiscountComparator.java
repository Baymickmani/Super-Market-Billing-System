package com.training.project.bean;

import java.util.Comparator;

public class ProductDiscountComparator implements Comparator<Product>{

	@Override
	public int compare(Product arg0, Product arg1) {
		if(arg0.getProductDiscountPercentage()>arg1.getProductDiscountPercentage())
			return 1;
		else if(arg0.getProductDiscountPercentage()<arg1.getProductDiscountPercentage())
			return -1;
		else
			return 0;
	}

}
