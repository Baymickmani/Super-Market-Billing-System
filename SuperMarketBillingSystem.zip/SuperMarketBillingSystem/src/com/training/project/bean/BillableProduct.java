package com.training.project.bean;

import javax.persistence.Embeddable;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Proxy;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.context.annotation.Lazy;



@Embeddable
@Proxy(lazy=false)
public class BillableProduct {
	

	@OneToOne
	Product product;
	@NotEmpty(message="Quantity cannot be blank")
	int quantity;
	double productTotal;
	
	
	public BillableProduct() {
		super();
	}


	public BillableProduct(Product product, int quantity,double productTotal) {
		super();
		this.product = product;
		this.quantity = quantity;
		this.productTotal=productTotal;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public double getProductTotal() {
		return productTotal;
	}


	public void setProductTotal(double productTotal) {
		this.productTotal = productTotal*this.quantity;
	}


	
	
	
	
}
