package com.training.project.bean;

import java.util.Comparator;

public class CategoryComparator implements Comparator<Product>{

	@Override
	public int compare(Product arg0, Product arg1) {

		if(arg0.getCategory().compareTo(arg1.getCategory())<0)
			return -1;
		if(arg0.getCategory().compareTo(arg1.getCategory())>0)
			return 1;
		return 0;
	}
	
	
}
