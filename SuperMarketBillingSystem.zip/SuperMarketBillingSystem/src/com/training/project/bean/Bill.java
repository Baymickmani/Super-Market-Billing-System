package com.training.project.bean;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Proxy;
@Entity
@Table(name="BillDetails")
@Proxy(lazy=false)
public class Bill {
	@Id
	@SequenceGenerator(name="bill_seq1",sequenceName="bill_seq",initialValue=10001,allocationSize=1)
	@GeneratedValue(generator="bill_seq1",strategy=GenerationType.SEQUENCE)
	private int billId;
	private double billTotal;
	@Temporal(TemporalType.DATE)
	private Date billDate;
	private int points;
	@ManyToOne
	private Customer customer;
	@ElementCollection
	@OrderColumn(name="IDX")
	@CollectionTable(name="billableProducts" )
	@Embedded
	private List<BillableProduct> billableProducts;
	
	
	public Bill() {
		super();
		this.billableProducts=new ArrayList<BillableProduct>();
	}

	
	public Bill(double billTotal, Date billDate, int points, Customer customer,
			List<BillableProduct> billableProducts) {
		super();
		this.billTotal = billTotal;
		this.billDate = billDate;
		this.points = points;
		this.customer = customer;
		this.billableProducts=new ArrayList<BillableProduct>();
	}


	public Bill(int billId, double billTotal, Date billDate, int points,
			Customer customer, List<BillableProduct> billableProducts) {
		super();
		this.billId = billId;
		this.billTotal = billTotal;
		this.billDate = billDate;
		this.points = points;
		this.customer = customer;
		this.billableProducts=new ArrayList<BillableProduct>();
	}


	public int getBillId() {
		return billId;
	}


	public void setBillId(int billId) {
		this.billId = billId;
	}


	public double getBillTotal() {
		return billTotal;
	}


	public void setBillTotal(double billTotal) {
		this.billTotal = billTotal;
	}


	public Date getBillDate() {
		return billDate;
	}


	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}


	public int getPoints() {
		return points;
	}


	public void setPoints(int points) {
		this.points = points;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public List<BillableProduct> getBillableProducts() {
		return billableProducts;
	}


	public void setBillableProducts(List<BillableProduct> billableProducts) {
		this.billableProducts = billableProducts;
	}

	public void addBillableProduct(BillableProduct billableProduct){
		this.billableProducts.add(billableProduct);
	}


	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", billTotal=" + billTotal
				+ ", billDate=" + billDate + ", points=" + points
				 + ", billableProducts="
				+ billableProducts + "]";
	}



	
	
}
