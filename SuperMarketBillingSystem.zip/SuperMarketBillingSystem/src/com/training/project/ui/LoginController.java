package com.training.project.ui;

import java.util.ArrayList;
import java.util.List;

import javax.naming.Binding;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.training.project.bean.Login;
import com.training.project.service.LoginService;
import com.training.project.service.LoginServiceImpl;

@Controller
public class LoginController {
	LoginServiceImpl service;

	public LoginServiceImpl getService() {
		return service;
	}

	public void setService(LoginServiceImpl service) {
		this.service = service;
	}
	@RequestMapping("/")
	public String f1(Model m) {
		m.addAttribute("login",new Login());
		return "Login";
	}
	@RequestMapping(value="/find",method=RequestMethod.POST)
	public String f2(@Valid @ModelAttribute("login")Login inputLogin,BindingResult bindingResult, Model m) {
		Login login=null;
		
		if(bindingResult.hasErrors()){
			System.out.println("has Errors");
			return "Login";
		}
		try {
			login=this.service.find(inputLogin.getUserName());
			if(login.equals(inputLogin) && inputLogin.getUserType()==1) {
				
				m.addAttribute("categories", category());
				return "ShowProducts";
			}
			else if(login.equals(inputLogin) && inputLogin.getUserType()==2) {
				return "BillerMenu";
			}
			else {
				m.addAttribute("Status","Username or password is incorrect");
			}
		} catch (Exception e) {
			m.addAttribute("Status","Data is Not Found");
		}
		
		return "Login";
	}
	public List<String> category(){
		List<String> categories=new ArrayList<String>();
		categories.add("Groceries");
		categories.add("Fashion");
		categories.add("Electronics");
		categories.add("Home Appliances");
		return categories;
	}
	
}
