package com.training.project.ui;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.project.bean.Bill;
import com.training.project.bean.Customer;
import com.training.project.bean.Product;
import com.training.project.service.BillService;
import com.training.project.service.CustomerService;
import com.training.project.service.ProductService;

@Controller
public class CustomerController {
	CustomerService service;
	BillService service1;
	ProductService service2;

	public CustomerService getService() {
		return service;
	}

	public void setService(CustomerService service) {
		this.service = service;
	}

	public BillService getService1() {
		return service1;
	}

	public void setService1(BillService service1) {
		this.service1 = service1;
	}
	
	public ProductService getService2() {
		return service2;
	}

	public void setService2(ProductService service2) {
		this.service2 = service2;
	}

	@RequestMapping(value = "/mobile")
	public String f1( Model m) {

		return "InputMobile";
	}

	@RequestMapping(value = "/findCustomer")
	public String f2( @RequestParam(name = "mobileNumber") String mobileNumber,Model m) {
		
		int points=0;
		Customer customer = null;
		List<Bill> bills=null;
		try {
			customer = this.service.findCustomer(mobileNumber);

			if (customer != null) {
				bills=customer.getBills();
				for(Bill b:bills)
				{
					if(b.getCustomer().getCustomerId()==customer.getCustomerId())
					points=points+b.getPoints();
				}
				m.addAttribute("products", f4());
				m.addAttribute("points",points);
				m.addAttribute("customer",customer);
				return "BillInput";
			} else {
				m.addAttribute("mobile",mobileNumber);
				m.addAttribute("customer", new Customer());
				return "CustomerInput";
			}
		} catch (Exception e) {
			m.addAttribute("mobile",mobileNumber);
			m.addAttribute("customer", new Customer());
			return "CustomerInput";
		}

	}

	@RequestMapping( value = "/addCustomer", method = RequestMethod.POST)
	public String f3(@Valid @ModelAttribute("customer")Customer customer,BindingResult bindingResult, Model m) {
		
		if(bindingResult.hasErrors()){
			System.out.println("has Errors");
			return "CustomerInput";
		}
		boolean result = false;
		try {
			result = this.service.add(customer);
			if (result == true) {
				m.addAttribute("points", 0);
				customer=this.service.findCustomer(customer.getCustomerMobile());
				m.addAttribute("customer", customer);
				m.addAttribute("products",f4());
				return "BillInput";
			} else {
				m.addAttribute("status", "Customer Not Added");
			}
		} catch (Exception e) {
			m.addAttribute("status", "Customer Not Added");
		}

		return "CustomerInput";
	}
	public List<Product> f4(){
		List<Product> products=null;
		try {
			products=this.service2.getAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return products;
	}
}
