package com.training.project.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.project.bean.Bill;
import com.training.project.bean.BillableProduct;
import com.training.project.bean.Customer;
import com.training.project.bean.Product;
import com.training.project.service.BillService;
import com.training.project.service.CustomerService;
import com.training.project.service.ProductService;

@Controller
public class BillController {
	BillService service;
	ProductService service1;
	CustomerService service2;
	
	Bill bill=null;
	

	public BillService getService() {
		return service;
	}

	public void setService(BillService service) {
		this.service = service;
	}

	public ProductService getService1() {
		return service1;
	}

	public void setService1(ProductService service1) {
		this.service1 = service1;
	}
	
	public CustomerService getService2() {
		return service2;
	}
	
	
	public void setService2(CustomerService service2) {
		this.service2 = service2;
	}

	@RequestMapping(value = "/calculateTotal")
	public String f2( @RequestParam(name="customer_mobile") String cust_mobile,Model m){
		double sum = 0;
		boolean result = false;
		List<BillableProduct> billableProducts = null;
		Customer customer=null;
		try {
			customer=this.service2.findCustomer(cust_mobile);
		} catch (Exception e1) {
			m.addAttribute("status","Error while finding the customer");
		}
		
		try {
			if (bill != null) {
				billableProducts = bill.getBillableProducts();
				for (BillableProduct b : billableProducts) {
					sum += b.getProductTotal();
				}
			}
			bill.setBillTotal(sum);
			if (sum >= 100)
				bill.setPoints(((int) bill.getBillTotal() / 100 * 2)
						+ bill.getPoints());
			result = this.service.addBill(bill);
			if (result == true) {
				m.addAttribute("bill", bill);
			}

		} catch (Exception e) {
			m.addAttribute("status", "error while adding the bill ");
			m.addAttribute("customer",customer);
			m.addAttribute("points",0);
			m.addAttribute("products", f8());
			return "BillInput";
		}
		customer.addBill(bill);
		String str=f7(bill.getBillId(),m);
		bill=null;
		m.addAttribute("customer",customer);
		return str;
	}

	@RequestMapping(value = "/findAndAdd")
	public String f1(@RequestParam(name = "product_id") int pid,
			@RequestParam(name = "product_quantity") int quantity,
			 @RequestParam(name="customer_mobile") String cust_mobile,
			 @RequestParam(name="points") int points,Model m) {
		Product product = null;
		boolean result = false;
		double sum=0;
		if(bill==null)
		{
			bill=new Bill();
			bill.setBillDate(new Date());
			Customer customer=null;
			try {
				customer=this.service2.findCustomer(cust_mobile);
			} catch (Exception e) {
				m.addAttribute("status", "Error while finding the customer");
			}
			bill.setCustomer(customer);
		}
		
		
		m.addAttribute("customer", bill.getCustomer());
		
		try {
			product = this.service1.findProduct(pid);
		} catch (Exception e1) {
			m.addAttribute("status", "Error while finding the product");
		}
		BillableProduct billableProduct = new BillableProduct();
		try {
			
			billableProduct.setQuantity(quantity);
			billableProduct.setProduct(product);
			billableProduct.setProductTotal(product.getProductValue(product));
			bill.addBillableProduct(billableProduct);
			
		} catch (Exception e) {
			m.addAttribute("status", "Error while setting the products");
		}
		for(BillableProduct bp:bill.getBillableProducts()){
			sum+=bp.getProductTotal();
		}
		bill.setBillTotal(sum);
		m.addAttribute("bill", bill);
		m.addAttribute("points",points);
		m.addAttribute("products",f8());
		return "BillInput";
	}

	@RequestMapping(value = "/inputDate")
	public String f3(Model m) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		m.addAttribute("date", sdf.format(new Date()));
		return "ManageBills";

	}

	@RequestMapping(value = "/retrieveBills")
	public String f4(@RequestParam(name = "txtDate") String date,
			@RequestParam(name = "idx") int idx,
			Model m) {
		List<Bill> bills = null;
		List<Bill> showingBills = new ArrayList<Bill>();
		int dayTotal=0,dayPoints=0;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date1=null;
		try {
			date1 = sdf.parse(date);
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		String dateStr=null;
		Calendar calendar=Calendar.getInstance();
		calendar.setTime(date1);
		if(idx==1)
			dateStr=sdf.format(date1);
		else if(idx==2) {
			calendar.add(Calendar.DAY_OF_YEAR,-1);
			dateStr=sdf.format(calendar.getTime());
		}
		else {
			calendar.add(Calendar.DAY_OF_YEAR,1);
			dateStr=sdf.format(calendar.getTime());
		}
		try {
			bills = this.service.getAllBills();
			if (bills == null) {
				m.addAttribute("status", "No bills to display");
			} else {
				for (Bill bill : bills) {
					Date billDate = bill.getBillDate();
					if (sdf.format(billDate).equals(dateStr)) {
						showingBills.add(bill);
						dayTotal+=bill.getBillTotal();
						dayPoints+=bill.getPoints();
						
					}
					
				}
				if(showingBills.size()==0){
					m.addAttribute("nullOrNot",1);
					m.addAttribute("date",sdf.format(sdf.parse(dateStr)));
					m.addAttribute("status", "No Bills found for this date");
				}
				else {
					m.addAttribute("bills", showingBills);
					m.addAttribute("date",sdf.format(sdf.parse(dateStr)));
					m.addAttribute("dayTotal", dayTotal);
					m.addAttribute("dayPoints",dayPoints);
				}
			}
		} catch (Exception e) {
			m.addAttribute("status", "Error while retreiving the bills");
		}
		
		return "ManageBills";
	}
	@RequestMapping(value="/cancelBill")
	public String f5() {
		bill=null;
		return "InputMobile";
	}
	
	@RequestMapping(value="/showRespectiveBill")
	public String f6(@RequestParam(name="billId")int billId,Model m) {
		try {
			Bill bill=this.service.findBill(billId);
			System.out.println(bill);
			if(bill.getBillableProducts().size()==0)
				m.addAttribute("status","No Products in this Bill");
			m.addAttribute("bill",bill);
		} catch (Exception e) {
			m.addAttribute("status", "No Products in this Bill");
		}
		return "DisplayBill";
	}
	
	public String f7(int billId,Model m) {
		try {
			Bill bill=this.service.findBill(billId);
			if(bill.getBillableProducts().size()==0)
				m.addAttribute("status","No Products in this Bill");
			m.addAttribute("bill",bill);
		} catch (Exception e) {
			m.addAttribute("status", "No Products in this Bill");
		}
		return "DisplayBill";
	}
	
	public List<Product> f8(){
		List<Product> products=null;
		try {
			products=this.service1.getAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return products;
	}
}
