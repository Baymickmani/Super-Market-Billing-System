package com.training.project.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.project.bean.CategoryComparator;
import com.training.project.bean.Login;
import com.training.project.bean.Product;
import com.training.project.bean.ProductDiscountComparator;
import com.training.project.bean.ProductMRPComparator;
import com.training.project.bean.ProductNameComparator;
import com.training.project.service.ProductService;
@Controller
public class ProductController {
	ProductService service;

	public ProductService getService() {
		return service;
	}

	public void setService(ProductService service) {
		this.service = service;
	}
	@RequestMapping(value="/showAll")
	public String f1(Model m) {
		List<Product> products=null;
		List<String> categories=category();
		m.addAttribute("categories",categories);
		try {
			products=this.service.getAll();
			Collections.sort(products, new CategoryComparator());
			if(products.size()!=0)
				m.addAttribute("products", products);
			else
				m.addAttribute("status", "No products to Display");
		} catch (Exception e) {
			m.addAttribute("status", "Error while retrieving the data");
		}
		return "ShowProducts";
	}
	
	@RequestMapping(value="/productInput")
	public String f2(Model m) {
		List<String> categories=new ArrayList<String>();
		categories.add("Groceries");
		categories.add("Fashion");
		categories.add("Electronics");
		categories.add("Home Appliances");
		m.addAttribute("categories", categories);
		m.addAttribute("product",new Product());
		return "AddProducts";
		
	}
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String f3(@Valid @ModelAttribute("product")Product product,BindingResult bindingResult,Model m) {
		if(bindingResult.hasErrors()){
			System.out.println("has Errors");
			m.addAttribute("categories", category());
			return "AddProducts";
		}
		boolean result=false;
		product.setProductName(product.getProductName().toUpperCase());
		try {
			result=this.service.addProduct(product);
			if(result==true)
				return f1(m);
			else
			{
				m.addAttribute("status", "Product Not Added");
			}
		} catch (Exception e) {
			m.addAttribute("status", "Product Not Added");
		}
		return "AddProducts";
	}
	@RequestMapping("/findProduct")
	public String f4(@RequestParam("p_id")int id,@RequestParam("p_control")String control,Model m) {
		System.out.println(id);
		Product product=null;
		List<String> categories=new ArrayList<String>();
		categories.add("Groceries");
		categories.add("Fashion");
		categories.add("Electronics");
		categories.add("Home Appliances");
		m.addAttribute("categories", categories);
		try {
			product=this.service.findProduct(id);
			if(product!=null){
				m.addAttribute("product",product);
			}
		} catch (Exception e) {
			m.addAttribute("product","Error while finding the product");
		}
		if(control.equals("delete"))
		return "ShowProductToDelete";
		else
		return "EditProduct";

	}
	@RequestMapping("/deleteProduct")
	public String f5(@RequestParam("p_id")int pid,Model m) {
		boolean result=false;
		Product product=new Product();
		product.setProductId(pid);
		try {
			result=this.service.deleteProduct(product);
		} catch (Exception e) {
			m.addAttribute("status", "Error while deleting the product");
		}
		if(result==true)
			m.addAttribute("status","Deleted Successfully");
		else
			m.addAttribute("status","Error while deleting");
		return f1(m);
	}
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String f6(@Valid @ModelAttribute("product")Product product,BindingResult bindingResult,Model m) {
		boolean result=false;
		if(bindingResult.hasErrors()){
			System.out.println("has Errors");
			m.addAttribute("product",product);
			m.addAttribute("categories", category());
			return "EditProduct";
		}
		try {
			result=this.service.updateProduct(product);
			if(result==true){
				m.addAttribute("productId",product.getProductId());
				m.addAttribute("status","Product Updated");
				return f1(m);
			}
			else
			{
				m.addAttribute("status", "Product Not Updated");
			}
		} catch (Exception e) {
			m.addAttribute("status", "Product Not Updated");
		}
		return f1(m);
	}
	
	@RequestMapping(value="/filter")
	public String f7(@RequestParam(name="txt_category") String category,Model m){
		List<Product> products=null;
		List<Product> filteredProducts=new ArrayList<Product>();
		try {
			products=this.service.getAll();
			if(products.size()!=0){
				for(Product product:products)
				{
					if(product.getCategory().equals(category))
						filteredProducts.add(product);
				}
				if(filteredProducts.size()!=0)
				m.addAttribute("products", filteredProducts);
				else
				m.addAttribute("status", "No products in this category");
				
				m.addAttribute("categories",category());
			}
			else{
				m.addAttribute("status", "No products");
				m.addAttribute("categories",category());
				
			}
		} catch (Exception e) {
			m.addAttribute("status", "Error while filtering the data");
		}
		
		return "ShowProducts";
	}
	
	@RequestMapping(value="/logout")
	public String f8(Model m){
		m.addAttribute("login",new Login());
		return "Login";
	}
	public List<String> category(){
		List<String> categories=new ArrayList<String>();
		categories.add("Groceries");
		categories.add("Fashion");
		categories.add("Electronics");
		categories.add("Home Appliances");
		return categories;
	}
	@RequestMapping(value="/sort1")
	public String f9(@RequestParam(name="sortInd") int basedOn,@RequestParam(name="counter") int counter,Model m){
		List<Product> products=null;
		try {
			products = this.service.getAll();
			
			System.out.println(products.size());
		} catch (Exception e) {
			m.addAttribute("products", "Error while finding the data");
		}
		if(basedOn==1)
		Collections.sort(products,new CategoryComparator());
		else if(basedOn==2)
		Collections.sort(products,new ProductNameComparator());
		else if(basedOn==3)
		Collections.sort(products, new ProductMRPComparator());
		else if(basedOn==4)
		Collections.sort(products, new ProductDiscountComparator());
		else
		Collections.sort(products,new CategoryComparator());
		
		if(counter%2==0)
			Collections.reverse(products);
		m.addAttribute("categories",category());
		m.addAttribute("products", products);
		return "ShowProducts";
	}
	
}
